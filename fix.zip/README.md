<div align="right">
<img width="32px" src="img/algo2.svg">
</div>

# TP2

## Repositorio de (Nombre Apellido) - (Padrón) - (Mail)

- Para compilar:

```bash
gcc -std=c99 -Wall -Wconversion -Wtype-limits -pedantic -Werror -O2 -g src/*.c tp2.c -o tp2
```

- Para ejecutar:

```bash
./tp2
```

- Para ejecutar con valgrind:
```bash
valgrind --leak-check=full --track-origins=yes --show-reachable=yes --show-leak-kinds=all ./tp2
```

- Para compilar las pruebas:

```bash
gcc -std=c99 -Wall -Wconversion -Wtype-limits -pedantic -Werror -O2 -g src/*.c pruebas_alumno.c -o pruebas_alumno
```

- Para ejecutar las pruebas con valgrind:

```bash
valgrind --leak-check=full --track-origins=yes --show-reachable=yes --error-exitcode=2 --show-leak-kinds=all ./pruebas_alumno
```
---
##  Funcionamiento

### Descripción General

El TP2 implementa un juego de memoria (memotest) de pokemones con un sistema de menús interactivo. El programa utiliza estructuras de datos (lista, pila, ABB, hash) para gestionar la información de pokemones y las partidas.

---

## TDA Menu (`menu.h`)

### Primitivas Principales

**`menu_t *menu_crear(const char *titulo, enum estilo_menu estilo)`**
- Crea un menú con un título personalizado y un estilo visual (MINIMALISTA, BORDES, o RETRO)
- Si el título es NULL, usa "MENU" por defecto
- Retorna un puntero al menú creado o NULL en caso de error

**`menu_t *menu_agregar_opcion(menu_t *menu, char tecla, const char *descripcion, void (*accion)(void *), menu_t *submenu, void *ctx)`**
- Agrega una opción al menú con una tecla asociada
- Puede tener una acción (callback) o un submenú, pero no ambos
- Si la tecla ya existe, reemplaza la opción anterior
- El array de opciones se expande dinámicamente según sea necesario

**`enum estilo_menu menu_obtener_estilo(menu_t *menu)`**
- Retorna el estilo actual del menú
- Si el menú es NULL, retorna ESTILO_MINIMALISTA por defecto

**`menu_t *menu_cambiar_estilo(menu_t *menu)`**
- Cambia el estilo del menú de forma cíclica: MINIMALISTA → BORDES → RETRO → MINIMALISTA
- Retorna el mismo menú con el estilo actualizado

**`void menu_destruir(menu_t *menu)`**
- Libera toda la memoria asociada al menú
- Destruye recursivamente los submenús
- No libera los contextos de usuario (`ctx`)

### Funcionamiento del Sistema de Menús

El menú se implementa con un array dinámico de opciones que crece según sea necesario (similar al TP1). Cada opción tiene:
- Una tecla (char) como identificador
- Una descripción (string)
- Una acción (función callback) o un submenú (pero no ambos)
- Un contexto de usuario que se pasa a la acción

El menú soporta navegación jerárquica mediante submenús, permitiendo crear estructuras complejas de navegación.

---

## TDA Juego (`juego.h`)

### Primitivas de Inicialización

**`juego_t *juego_crear()`**
- Crea una nueva instancia del juego
- Inicializa las estructuras internas: lista (pokedex), hash (búsqueda por nombre), lista (cartas), pila (historial)
- Retorna el juego creado o NULL en caso de error

**`int juego_cargar_pokedex(juego_t *juego, const char *archivo)`**
- Carga pokemones desde un archivo CSV
- **Importante**: Crea copias profundas de cada pokemon (no guarda referencias directas)
- Retorna la cantidad de pokemones cargados o -1 en caso de error
- Los pokemones se almacenan en una lista y también en un hash para búsquedas rápidas por nombre

**`void juego_destruir(juego_t *juego)`**
- Libera toda la memoria del juego
- Destruye los pokemones copiados (tanto nombres como estructuras)
- Libera las cartas y el historial de jugadas

### Primitivas de Consulta

**`size_t juego_cantidad_pokemones(juego_t *juego)`**
- Retorna la cantidad de pokemones cargados en la pokedex

**`size_t juego_buscar_por_nombre(juego_t *juego, const char *nombre, pokemon_t **resultados, size_t max_resultados)`**
- Busca pokemones cuyo nombre contenga la subcadena especificada
- Utiliza búsqueda lineal con `strstr` para encontrar coincidencias parciales
- Llena el array de resultados hasta `max_resultados`

**`pokemon_t *juego_buscar_por_id(juego_t *juego, int id)`**
- Busca un pokemon por su ID exacto
- Utiliza un iterador sobre la lista de pokemones

**`void juego_listar_por_nombre(juego_t *juego, void (*accion)(pokemon_t *, void *), void *ctx)`**
- Lista todos los pokemones ordenados alfabéticamente por nombre
- Crea un ABB temporal para ordenar, extrae los elementos en inorden, y ejecuta la acción sobre cada uno

**`void juego_listar_por_id(juego_t *juego, void (*accion)(pokemon_t *, void *), void *ctx)`**
- Lista todos los pokemones ordenados por ID
- Utiliza el mismo mecanismo de ABB temporal que el listado por nombre

### Primitivas de Partida

**`bool juego_iniciar_partida(juego_t *juego, unsigned int semilla)`**
- Inicia una nueva partida con al menos 9 pokemones
- Genera 18 cartas (9 pares) seleccionando pokemones aleatoriamente
- Las mezcla usando el algoritmo Fisher-Yates
- Si la semilla es 0, usa el tiempo actual

**juego_partida_activa()**
- Verifica si hay una partida en curso (con 18 cartas en el tablero)

**
 juego_jugador_actual()**
- Retorna el jugador actual (1 o 2)
- Retorna 0 si no hay partida activa

**size_t juego_obtener_tablero()**
- Copia el estado actual de las 18 cartas al array proporcionado
- Cada carta contiene: posición, puntero al pokemon, estado (descubierta/emparejada)

**int juego_seleccionar_carta()**
- Selecciona una carta en la posición especificada
- Si es la primera carta: la descubre y retorna 0
- Si es la segunda carta:
  - **Par correcto**: marca ambas como emparejadas, suma 1 punto al jugador actual, retorna 1
  - **Par incorrecto**: las vuelve a ocultar, cambia de turno, retorna -2
- Registra la jugada en el historial (pila)

**int juego_obtener_puntuacion(r)**
- Retorna los puntos del jugador especificado (1 o 2)

**size_t juego_obtener_ultimas_jugadas()**
- Obtiene las últimas N jugadas del historial
- Utiliza una pila auxiliar para extraer y recolocar las jugadas

**size_t juego_obtener_jugadas_jugador()**
- Obtiene las últimas N jugadas de un jugador específico
- Filtra el historial por el jugador solicitado

**juego_partida_terminada()**
- Verifica si todas las cartas están emparejadas

**int juego_obtener_ganador()**
- Retorna el jugador ganador (1 o 2), 0 en caso de empate, o -1 si la partida no terminó

**void juego_finalizar_partida()**
- Finaliza la partida actual
- Libera las cartas y el historial de jugadas
- Resetea los puntajes

### Primitivas de Cartas

**void juego_crear_cartas_memoria()**
- Genera 18 cartas (9 pares) seleccionando pokemones aleatorios
- Mezcla las cartas usando Fisher-Yates
- Actualiza las posiciones de cada carta

### Primitivas de Conversión de Tipos

**enum tipo_pokemon juego_tipo_desde_string()**
- Convierte un string ("ELEC", "FUEG", etc.) a su enumeración correspondiente
- Retorna TIPO_NORM para strings inválidos o NULL

**const char *juego_tipo_a_string()**
- Convierte un tipo de pokemon a su representación en string
- Retorna "NORM" para tipos inválidos

---

## Decisiones de Diseño Importantes

### 1. Copia Profunda de Pokemones
Para evitar problemas de use-after-free, cuando se cargan pokemones desde el archivo, el juego crea **copias profundas** de cada pokemon (incluyendo el nombre con `strdup`). Esto permite que `tp1_destruir` libere su memoria sin afectar los pokemones almacenados en el juego.

```c
struct pokemon *copia = malloc(sizeof(struct pokemon));
copia->nombre = strdup(pokemon->nombre);
// ... copiar otros campos
```

### 2. Uso de Estructuras de Datos

- **Lista**: Para almacenar la pokedex y las cartas del juego
- **Hash**: Para búsquedas rápidas de pokemones por nombre
- **ABB**: Temporal, para ordenar pokemones al listar
- **Pila**: Para mantener el historial de jugadas (LIFO)

### 3. Gestión del Historial de Jugadas

El historial se implementa con una pila. Para obtener las últimas N jugadas sin perder datos, se usa una pila auxiliar:
1. Extraer N elementos de la pila original → pila auxiliar
2. Copiar los datos al array de resultados
3. Devolver los elementos de la pila auxiliar → pila original

### 4. Sistema de Turnos

El juego alterna entre jugadores cuando ocurre un error (par incorrecto). Cuando un jugador acierta, mantiene el turno para la siguiente jugada.

---

## Estructuras de Datos Utilizadas

<div align="center">
<img width="70%" src="img/juego.svg">
</div>

El diagrama muestra cómo se relacionan las estructuras internas del juego. La pokedex mantiene los pokemones originales, mientras que las cartas solo tienen referencias a estos pokemones.

<div align="center">
<img width="70%" src="img/menu.svg">
</div>

El menú mantiene un array dinámico de opciones que puede contener tanto acciones como submenús, permitiendo navegación jerárquica.

---

## Diagramas de Flujo - Primitivas Fundamentales con Memoria Dinámica

### 1. `juego_crear()` - Inicialización del Juego

```mermaid
flowchart TD
    A[Inicio: juego_crear] --> B[malloc juego_t]
    B --> C{¿malloc exitoso?}
    C -->|NO| D[return NULL]
    C -->|SÍ| E[juego->pokedex = lista_crear]
    E --> F{¿lista creada?}
    F -->|NO| G[free juego<br/>return NULL]
    F -->|SÍ| H[juego->pokedex_por_nombre<br/>= hash_crear 100]
    H --> I{¿hash creado?}
    I -->|NO| J[lista_destruir pokedex<br/>free juego<br/>return NULL]
    I -->|SÍ| K[juego->cartas = lista_crear]
    K --> L{¿lista creada?}
    L -->|NO| M[hash_destruir<br/>lista_destruir<br/>free juego<br/>return NULL]
    L -->|SÍ| N[juego->historial = pila_crear]
    N --> O{¿pila creada?}
    O -->|NO| P[Destruir todo<br/>return NULL]
    O -->|SÍ| Q[Inicializar campos:<br/>partida_activa=false<br/>jugador_actual=0<br/>puntajes=0]
    Q --> R[return juego]
    
    style B fill:#ff9999
    style E fill:#ff9999
    style H fill:#ff9999
    style K fill:#ff9999
    style N fill:#ff9999
    style Q fill:#99ff99
```

**Memoria Dinámica:**
- 1 `malloc` para la estructura principal
- 2 `lista_crear()` (pokedex y cartas)
- 1 `hash_crear()` (búsqueda por nombre)
- 1 `pila_crear()` (historial)

---

### 2. `juego_cargar_pokedex()` - Copia Profunda de Pokemones

```mermaid
flowchart TD
    A[Inicio: insertar_pokemon_en_juego] --> B[Recibe pokemon original<br/>desde tp1]
    B --> C[malloc struct pokemon]
    C --> D{¿malloc exitoso?}
    D -->|NO| E[return false]
    D -->|SÍ| F[copia->id = pokemon->id<br/>copia->tipo = pokemon->tipo<br/>etc...]
    F --> G[copia->nombre = strdup pokemon->nombre]
    G --> H{¿strdup exitoso?}
    H -->|NO| I[free copia<br/>return false]
    H -->|SÍ| J[lista_agregar pokedex, copia]
    J --> K{¿agregado?}
    K -->|NO| L[free copia->nombre<br/>free copia<br/>return false]
    K -->|SÍ| M[hash_insertar nombre, copia]
    M --> N{¿insertado?}
    N -->|NO| O[lista_eliminar último<br/>free nombre<br/>free copia<br/>return false]
    N -->|SÍ| P[return true]
    
    Q[Después: tp1_destruir] --> R[Libera pokemon original]
    R --> S[El juego mantiene<br/>su COPIA independiente]
    
    style C fill:#ff9999
    style G fill:#ff9999
    style J fill:#ffcc99
    style M fill:#ffcc99
    style P fill:#99ff99
    style S fill:#99ccff
```

**Memoria Dinámica:**
- `malloc` para cada estructura pokemon
- `strdup` para cada nombre (copia profunda)
- Las copias se insertan en lista y hash
- **Crucial**: Evita use-after-free cuando se destruye tp1

---

### 3. `menu_agregar_opcion()` - Expansión Dinámica del Array

```mermaid
flowchart TD
    A[Inicio: menu_agregar_opcion] --> B{¿Tecla ya existe?}
    B -->|SÍ| C[Reemplazar opción existente<br/>sin reasignar memoria]
    B -->|NO| D{¿capacidad llena?}
    C --> Z[return menu]
    
    D -->|NO| E[Usar espacio disponible<br/>cantidad++]
    D -->|SÍ| F[nueva_cap = capacidad * 2]
    F --> G[realloc opciones, nueva_cap]
    G --> H{¿realloc exitoso?}
    H -->|NO| I[return NULL]
    H -->|SÍ| J[menu->opciones = nuevo_array<br/>menu->capacidad = nueva_cap]
    
    E --> K[Copiar datos a opciones cantidad]
    J --> K
    K --> L[opcion->tecla = tecla]
    L --> M[opcion->descripcion = strdup desc]
    M --> N{¿strdup exitoso?}
    N -->|NO| O[return NULL]
    N -->|SÍ| P[opcion->accion = accion<br/>opcion->submenu = submenu<br/>opcion->ctx = ctx]
    P --> Q[cantidad++]
    Q --> Z
    
    style G fill:#ff9999
    style M fill:#ff9999
    style J fill:#ffcc99
    style Z fill:#99ff99
```

**Memoria Dinámica:**
- `realloc` para expandir el array de opciones (x2)
- `strdup` para cada descripción
- Similar a la estrategia del TP1 con arrays dinámicos

---

### 4. `juego_seleccionar_carta()` - Segunda Carta con Jugada

```mermaid
flowchart TD
    A[Inicio: manejar_segunda_carta] --> B[carta_actual->descubierta = true]
    B --> C[Buscar posiciones de ambas cartas<br/>en la lista]
    C --> D{¿Mismo pokemon?<br/>primera == actual}
    
    D -->|SÍ PAR| E[malloc jugada_t]
    D -->|NO| F[malloc jugada_t]
    
    E --> G{¿malloc exitoso?}
    G -->|NO| H[Continuar sin registrar]
    G -->|SÍ| I[jugada->jugador = actual<br/>jugada->carta1 = pos1<br/>jugada->carta2 = pos2<br/>jugada->acierto = true]
    I --> J[strncpy nombre_pokemon]
    J --> K[pila_apilar historial, jugada]
    K --> L[primera->emparejada = true<br/>segunda->emparejada = true]
    L --> M[puntaje jugador_actual ++]
    M --> N[return 1<br/>SIGUE MISMO JUGADOR]
    
    F --> O{¿malloc exitoso?}
    O -->|NO| H
    O -->|SÍ| P[jugada->acierto = false<br/>llenar datos]
    P --> Q[pila_apilar historial, jugada]
    Q --> R[primera->descubierta = false<br/>segunda->descubierta = false]
    R --> S[jugador_actual =<br/>jugador_actual == 1 ? 2 : 1]
    S --> T[return -2<br/>CAMBIO DE TURNO]
    
    style E fill:#ff9999
    style F fill:#ff9999
    style K fill:#ffcc99
    style Q fill:#ffcc99
    style N fill:#99ff99
    style T fill:#ff9999
```

**Memoria Dinámica:**
- `malloc` para cada jugada_t registrada
- Se apila en el historial (pila)
- Persiste hasta `juego_finalizar_partida()` o `juego_destruir()`

---

### 5. `juego_destruir()` - Liberación Completa de Memoria

```mermaid
flowchart TD
    A[Inicio: juego_destruir] --> B{¿juego != NULL?}
    B -->|NO| Z[return]
    B -->|SÍ| C[Iterar pokedex]
    
    C --> D[Para cada pokemon:]
    D --> E[free pokemon->nombre<br/>strdup liberado]
    E --> F[free pokemon<br/>malloc liberado]
    F --> G{¿Más pokemones?}
    G -->|SÍ| D
    G -->|NO| H[lista_destruir pokedex]
    
    H --> I[hash_destruir pokedex_por_nombre<br/>no libera pokemones solo estructura]
    
    I --> J{¿cartas existe?}
    J -->|SÍ| K[Para cada carta:]
    K --> L[free carta<br/>malloc liberado]
    L --> M{¿Más cartas?}
    M -->|SÍ| K
    M -->|NO| N[lista_destruir cartas]
    J -->|NO| N
    
    N --> O{¿historial existe?}
    O -->|SÍ| P[Mientras pila no vacía:]
    P --> Q[jugada = pila_desapilar]
    Q --> R[free jugada]
    R --> S{¿Pila vacía?}
    S -->|NO| P
    S -->|SÍ| T[pila_destruir historial]
    O -->|NO| T
    
    T --> U[free juego]
    U --> Z
    
    style E fill:#ff6666
    style F fill:#ff6666
    style L fill:#ff6666
    style R fill:#ff6666
    style U fill:#ff6666
    style Z fill:#99ff99
```

**Memoria Dinámica Liberada:**
- Cada `pokemon->nombre` (strdup)
- Cada `pokemon` (malloc)
- Cada `carta` (malloc)
- Cada `jugada` (malloc)
- Estructura principal `juego` (malloc)
- Estructuras internas: lista, hash, pila

---

### 6. `juego_crear_cartas_memoria()` - Generación Aleatoria y Mezcla

```mermaid
flowchart TD
    A[Inicio: juego_crear_cartas_memoria] --> B[array usados = false]
    B --> C[pares_creados = 0]
    C --> D{pares_creados < 9?}
    
    D -->|NO| P[mezclar_cartas Fisher-Yates]
    D -->|SÍ| E[idx = rand % total_pokemones]
    E --> F{usados idx == false?}
    F -->|NO| E
    F -->|SÍ| G[pokemon = lista_buscar idx]
    G --> H[carta1 = malloc sizeof carta_t]
    H --> I[carta2 = malloc sizeof carta_t]
    I --> J{¿malloc exitoso ambas?}
    
    J -->|NO| K[free carta1<br/>free carta2<br/>continue]
    J -->|SÍ| L[carta1->pokemon = pokemon<br/>carta2->pokemon = pokemon<br/>descubierta=false<br/>emparejada=false]
    L --> M[lista_agregar cartas, carta1<br/>lista_agregar cartas, carta2]
    M --> N{¿agregadas ambas?}
    N -->|NO| K
    N -->|SÍ| O[usados idx = true<br/>pares_creados++]
    O --> D
    
    P --> Q[Fisher-Yates:<br/>Para i de n-1 a 1]
    Q --> R[j = rand % i+1<br/>swap array i, array j]
    R --> S[actualizar_posiciones_cartas]
    S --> T[Para cada carta i:<br/>carta->posicion = i]
    T --> Z[FIN]
    
    style H fill:#ff9999
    style I fill:#ff9999
    style M fill:#ffcc99
    style Z fill:#99ff99
```

**Memoria Dinámica:**
- 18 `malloc` para cartas (9 pares)
- Algoritmo Fisher-Yates usa array temporal
- Las cartas referencian pokemones existentes (no los copian)

---

## Resumen de Gestión de Memoria

| Primitiva | Allocations | Frees | Observaciones |
|-----------|-------------|-------|---------------|
| `juego_crear()` | 1 juego + 4 estructuras | En `juego_destruir()` | Validación exhaustiva |
| `juego_cargar_pokedex()` | N pokemones + N nombres | En `juego_destruir()` | **Copia profunda** |
| `menu_agregar_opcion()` | 1 descripción + realloc array | En `menu_destruir()` | Expansión x2 |
| `juego_seleccionar_carta()` | 1 jugada | En `juego_finalizar/destruir()` | Registro en pila |
| `juego_crear_cartas_memoria()` | 18 cartas | En `juego_finalizar/destruir()` | Referencias a pokemones |
| `juego_destruir()` | - | TODO lo anterior | Liberación completa |

### Validación con Valgrind
```
HEAP SUMMARY:
    in use at exit: 0 bytes in 0 blocks
  total heap usage: 1,755 allocs, 1,755 frees
  
ERROR SUMMARY: 0 errors from 0 contexts
```

✅ **Sin memory leaks, sin use-after-free, sin invalid reads**